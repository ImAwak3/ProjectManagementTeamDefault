<?php
define('EMAIL', 'koirala.kritika09@gmail.com');
define('PASSWORD', 'gmailAccount');
?>