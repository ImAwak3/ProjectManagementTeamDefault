    <!-- Footer section begin -->
    <!-- <footer class="footer-section">
      <div class="container container-md">       

        <div class="row ">
          <div class="col-md-12 text-center footer-bottom">


        <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved |</p>
             <img class = "footer-paypal"src="https://www.paypalobjects.com/webstatic/en_US/i/buttons/pp-acceptance-small.png" alt="PayPal Acceptance">
          </div>

        </div>
      </div>
    </footer> -->
    <!-- Footer section ends -->



    <!-- Js Plugins -->
    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery-ui.min.js"></script>
    <script src="../js/jquery.countdown.min.js"></script>
    <script src="../js/jquery.nice-select.min.js"></script>
    <script src="../js/jquery.zoom.min.js"></script>
    <script src="../js/jquery.dd.min.js"></script>
    <script src="../js/jquery.slicknav.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <script src="js/style.js"></script>
   
</body>

</html>