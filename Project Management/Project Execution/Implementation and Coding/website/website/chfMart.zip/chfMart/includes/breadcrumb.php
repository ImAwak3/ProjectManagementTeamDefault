
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text product-more">
                        <a href="./index.php"><i class="fa fa-home"></i> Home</a>
                        <a href="<?php echo $_SERVER['REQUEST_URI'];?>"><?php echo basename($_SERVER['PHP_SELF'], ".php")?></a>
                        <span>Detail</span>
                    </div>
                </div>
            </div>
        </div>
    </div>