<?php include 'includes/header.php';?>


<p>Thank you for registering. We have sent an verification email to your email address. Plese very your account before loging in to the wesbite.</p>

<?php include 'includes/footer.php';?>