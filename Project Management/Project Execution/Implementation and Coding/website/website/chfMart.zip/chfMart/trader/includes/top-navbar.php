<nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fa fa-navicon"></i>
                        <span>Sidebar</span>
                    </button>

                    <!-- top-header -->
                    <div class="header-top">
                        <ul class="nav">
                            <li class="nav-item active">
                                <a class="nav-link" href="#">Home</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-user"> Trader</i></a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="#">Profile</a>
                                        <a class="dropdown-item" href="#">Logout</a>
                                    </div>
                                
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>