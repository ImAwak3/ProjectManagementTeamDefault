<?php

include 'includes/header.php';
include 'includes/footer.php';
?>

    <div class="wrapper">
       <?php require 'includes/sidebar.php';?>

        <div id="content">
            <?php require 'includes/top-navbar.php';?>
        </div>
    </div>